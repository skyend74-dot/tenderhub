import { jsonOK } from '../../lib/http';
import { redis } from '../../lib/redis';

export const runtime = 'edge';

export default async function handler() {
  const demo = [
    { id:'L-1001', source:'etender', url:'#', title:'Поставка автошин 195/65R15', description:'Демо', category:'Авто и шины', buyer:'МВД РУз', region:'Ташкент', budget_amount:950000000, currency:'UZS', bid_deadline_at:new Date(Date.now()+28*3600e3).toISOString(), published_at:new Date(Date.now()-20*3600e3).toISOString(), status:'open' },
    { id:'L-1002', source:'xarid',   url:'#', title:'Рукава всасывающие D125',      description:'Демо', category:'Пожарная безопасность', buyer:'МЧС', region:'Самарканд', budget_amount:320000000, currency:'UZS', bid_deadline_at:new Date(Date.now()+6*3600e3).toISOString(),  published_at:new Date(Date.now()-40*3600e3).toISOString(), status:'open' },
  ];
  await redis.lpush('lots:latest', ...demo);
  return jsonOK({ seeded: demo.length });
}
